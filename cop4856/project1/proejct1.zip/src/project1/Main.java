package project1;
import java.util.Scanner;

public class Main {
	public static void main(String[] Args) {
		Parser parser = new Parser();
		
		parser.parse("gallery.xml");
	}
}
